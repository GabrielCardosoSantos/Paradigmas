/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bolachas;

/**
 *
 * @author gabri
 */
public class Triangulo extends Bolacha{
    private double base, alt;
    
    public Triangulo(double b, double h){
        this.base = b;
        this.alt = h;
        
        b = (b * h)/2;
        super.setTam(b);
        super.setEst("Triangulo");
        super.p = new Ponto(b, h);
    }
}
