/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bolachas;

/**
 *
 * @author gabri
 */
public class Retangulo extends Bolacha{
    private double base, altura;
    
    public Retangulo(double l, double a){
        this.base = l;
        this.altura = a;
        
        l = l * a;
        super.setTam(l);
        super.setEst("Retangulo");
        super.p = new Ponto(l, 10);
    }
}
