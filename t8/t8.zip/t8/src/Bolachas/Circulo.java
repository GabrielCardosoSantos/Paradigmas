/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bolachas;
/**
 *
 * @author gabri
 */
public class Circulo extends Bolacha{
    private double raio;
    
    public Circulo(double r){
        this.raio = r;
        r = Math.PI * Math.pow(r, 2);
        
        super.setTam(r);
        super.setEst("Circulo");
        super.p = new Ponto(r * 2, 10);
    }
    
}
