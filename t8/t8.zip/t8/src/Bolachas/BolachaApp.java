/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bolachas;

import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author gabri
 */
public class BolachaApp {

    public static void main(String[] args) {
        Bolacha maior;
        Random num = new Random();
        ArrayList<Bolacha> bolachas = new ArrayList();
        
        for(int i = 0; i < 50; i++){
            switch(num.nextInt(3)){
                case 0:
                    //Bolacha redonda
                    bolachas.add(new Circulo(num.nextDouble() * 3.5));
                    break;
                case 1:
                    //Bolacha retangular                    
                    bolachas.add(new Retangulo(num.nextDouble() * 10, num.nextDouble() * 5));
                    break;
                case 2:
                    //Bolacha triangular                    
                    bolachas.add(new Triangulo(num.nextDouble() * 10, num.nextDouble() * 8));
                    break;
            }
        }
        
        maior = bolachas.get(0);
        for (Bolacha b : bolachas){
            if (b.getTam() > maior.getTam()){
                maior = b;
            }
        }
        System.out.println(maior);
    }
    
}
