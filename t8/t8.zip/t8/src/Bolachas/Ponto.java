/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bolachas;

/**
 *
 * @author gabri
 */
public class Ponto {

    private static double posX = 0; //posição lado a lado
    private double x;
    private double y;
    
    public Ponto (){
        x = 0.0;
        y = 0.0;
    }
    
    public Ponto (double x1, double y1){
        posX += x1;
        x = x1 + posX;
        y = y1;
    }
    
    public double distancia(Ponto p1){
        double x1, y1, dist;
        
        x1 = p1.x - x;
        y1 = p1.y - y;
        dist = Math.sqrt(x1*x1 + y1*y1);
        return dist;
    }
    
    @Override
    public String toString(){
        return ("X: " + this.x + "\nY: " + this.y);
    }
}
