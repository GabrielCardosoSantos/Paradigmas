/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bolachas;
/**
 *
 * @author gabri
 */
abstract class Bolacha {
    private Double tamanho;
    private String estilo;
    
    Ponto p;
   
    public void setEst (String s){
        this.estilo = s;
    }
    
    public void setTam(double i){
        this.tamanho = i;
    }
    
    public double getTam(){
        return tamanho;
    }
    
    @Override
    public String toString(){
        return (this.estilo + " : " + this.tamanho.toString() + "\n" + this.p.toString());
    }
}
